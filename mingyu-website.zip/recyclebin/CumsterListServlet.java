@WebServlet("/student/list")
public class StudentListServlet2 extends GenericServlet { // GenericServlet 상속

    @Override // service 오버라이드
    public void service(ServletRequest servletRequest, ServletResponse servletResponse) throws ServletException, IOException {
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        Properties jdbcProperties = new Properties();
        jdbcProperties.setProperty("user", "username");
        jdbcProperties.setProperty("password", "****");
    }
}
try {
        // 1. JDBC 드라이버 로딩
        // MySQL : com.mysql.cj.jdbc.Driver
        DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
        } catch (SQLException e) {
        throw new ServletException(e);
        } finally {
        }